# We need 3 files to obtain the proper list of SRA access code for each cell line
library("GEOquery")

# Import list of "Good cell data" downloaded from https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE117872
goodCells <- read.table("GSE117872_good_Data_cellinfo.txt", header = TRUE, sep = '\t', stringsAsFactors = FALSE)
goodCells$grp_scrna <- paste0(goodCells$groups, " (scRNA-seq)")

# Import series_matrix file SOFT formatted to obtain match between sample name and GSM id
GSMdata <- getGEO("GSE117872")
GSMdata <- GSMdata$GSE117872_series_matrix.txt.gz

# Import SRArunTable to obtain SRR access to download FASTQ files
SRAtable <- read.table("SraRunTable.txt", header = TRUE, sep = ',')

# Filter out non good cell data from GSMdata
GSMfilt <- GSMdata[,GSMdata$title %in% goodCells$grp_scrna]

# Filter out non good cell data from SRArunTable
SRAtablefilt <- SRAtable[SRAtable$Sample.Name %in% GSMfilt$geo_accession,]

# Merge RHH id into SRArunTable
RHH_GSM <- data.frame(GSM = as.character(GSMfilt$geo_accession),
                       RHH = as.character(GSMfilt$title), 
                      stringsAsFactors = FALSE)

# Remove unnecessary "(scRNA-seq)" from RHH ids
RHH_GSM$RHH <- sapply(RHH_GSM$RHH, FUN = function(x) {unlist(strsplit(x, split = ' '))[1]})

# Merging
SRAmerged <- merge(x = SRAtablefilt, y = RHH_GSM, by.x = "Sample.Name", by.y = "GSM", all.x = TRUE)

# Filter out "PAIRED END" library layout
SRAsingle <- SRAmerged[SRAmerged$LibraryLayout == "SINGLE",]

# Filter out sample with more than 1 Run
invalid = which(SRAsingle$Sample.Name%in%unique(as.character(SRAsingle$Sample.Name[which(duplicated(SRAsingle$Sample.Name))])))
SRAsingle_oneRun <- SRAsingle[-invalid,]

saveRDS(object = SRAsingle_oneRun, "SRAfinalTable.rds")

ListHN120P <- as.character(SRAsingle_oneRun$Run[startsWith(x = as.character(SRAsingle_oneRun$source_name), 
                                                           prefix = "HN120P")])
write.table(x = ListHN120P, file = "listSRA_HN120P.txt", quote = FALSE, sep = '\t', row.names = FALSE, col.names = FALSE)

ListHN120M <- as.character(SRAsingle_oneRun$Run[startsWith(x = as.character(SRAsingle_oneRun$source_name), 
                                                           prefix = "HN120M")])
write.table(x = ListHN120M, file = "listSRA_HN120M.txt", quote = FALSE, sep = '\t', row.names = FALSE, col.names = FALSE)

ListHN137P <- as.character(SRAsingle_oneRun$Run[startsWith(x = as.character(SRAsingle_oneRun$source_name), 
                                                           prefix = "HN137P")])
write.table(x = ListHN137P, file = "listSRA_HN137P.txt", quote = FALSE, sep = '\t', row.names = FALSE, col.names = FALSE)
